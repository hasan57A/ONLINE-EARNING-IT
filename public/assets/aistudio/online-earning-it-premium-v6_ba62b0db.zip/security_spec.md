# Firestore Security Specification (`ONLINE EARNING IT`)

## 1. Data Invariants
1. **Default Deny**: All unspecified paths under `/databases/{database}/documents` are strictly denied (`allow read, write: if false;`).
2. **Identity Integrity**: Every user-owned document (`users/{userId}`, `usageHistory/{entryId}`, `savedResults/{entryId}`, `supportTickets/{ticketId}`, `paymentRequests/{requestId}`) binds its ownership field (`id` or `userId`) to `request.auth.uid` on creation and makes ownership immutable after creation.
3. **Self-Assigned Role Prevention**: Users creating their own `/users/{userId}` document are strictly constrained to `role == 'user'` (unless verified via owner email whitelist) and `status == 'active'`, `planStatus == 'none'`. Regular users can never elevate `role`, `status`, `plan`, or `planStatus`.
4. **Master Gate & Relational Integrity**: Messages under `/supportTickets/{ticketId}/messages/{messageId}` verify parent ticket existence and ownership via `get(/databases/$(database)/documents/supportTickets/$(ticketId))`.
5. **Single-Use Pool Consumption Integrity**: Regular users can update pool records (`uaPool`, `leadsPool`, `numbersPool`, `mailsPool`) ONLY to transition `used` from `false` to `true` with `usedBy == request.auth.uid` and `usedAt == request.time`, locking all other fields and locking terminal `used == true` state against non-admin re-writes.
6. **Terminal Payment State Locking**: Once a `PaymentRequest` transitions from `pending` to `approved` or `declined`, non-admin users cannot update or re-submit it. Only verified admins may review (`pending -> approved | declined`) or override.
7. **Temporal Integrity & Path ID Hardening**: All document IDs are validated with `isValidId()` (`<= 128` chars, `^[a-zA-Z0-9_\-]+$`), all strings/lists have explicit `.size()` bounds, `createdAt == request.time` on create, `updatedAt == request.time` on create/update, and `createdAt` is immutable on update.
8. **Verified Email & PII Isolation**: All authenticated write rules require `request.auth.token.email_verified == true`. User profiles containing PII (`gmail`, `mobile`) and payment/history/ticket records restrict `get` and `list` strictly to the resource owner (`resource.data.userId == request.auth.uid`) or verified admin—never using blanket `isSignedIn()` reads or `get()`/`exists()` inside `allow list`.

---

## 2. The "Dirty Dozen" Adversarial Payloads

| # | Attack Vector | Target Path | Payload Summary | Expected Outcome |
|---|--------------|-------------|-----------------|------------------|
| 1 | **Self-Role Escalation** | `/users/{uid}` (create) | Authenticated user writes `role: "admin"` on own profile signup | `PERMISSION_DENIED` |
| 2 | **Profile Role Shadow Update** | `/users/{uid}` (update) | User updates `fullName` AND sneaks `role: "admin"` or `planStatus: "active"` | `PERMISSION_DENIED` |
| 3 | **Ghost Field Injection** | `/savedResults/{id}` (create) | Valid fields plus extra undocumented field `isVerified: true` | `PERMISSION_DENIED` |
| 4 | **Email Spoofing (Unverified Admin Email)** | `/tools/tool_ua` (update) | Token has `email: "arittechofficial@gmail.com"` with `email_verified: false` | `PERMISSION_DENIED` |
| 5 | **PII Blanket / Cross-User Read** | `/users/{otherUid}` (get) | User A tries to `get` User B's `/users/{otherUid}` profile | `PERMISSION_DENIED` |
| 6 | **Delegated Query / Cross-User List** | `/savedResults` (list) | User A queries `/savedResults` without scoping to `userId == uid` | `PERMISSION_DENIED` |
| 7 | **ID Poisoning (1MB / Bad Chars ID)** | `/usageHistory/{badId}` (create) | `badId` is `"../admin"` or 500-char string | `PERMISSION_DENIED` |
| 8 | **Pool Double-Spend / Terminal Lock Bypass** | `/uaPool/{id}` (update) | User B attempts to set `used: false` or overwrite `usedBy` on an already `used: true` UA | `PERMISSION_DENIED` |
| 9 | **Payment Self-Approval** | `/paymentRequests/{id}` (create/update) | User submits `status: "approved"` on create, or updates own `pending` payment to `approved` | `PERMISSION_DENIED` |
| 10 | **Timestamp Forgery** | `/supportTickets/{id}` (create) | Client sends past ISO string or `new Date()` instead of `request.time` (`serverTimestamp()`) | `PERMISSION_DENIED` |
| 11 | **Orphaned Support Message** | `/supportTickets/nonexistent/messages/{m}` (create) | User attempts to insert a message under a non-existent or another user's ticket | `PERMISSION_DENIED` |
| 12 | **Value Poisoning (Oversized String / Wrong Type)** | `/paymentRequests/{id}` (create) | User sets `amount: "free"` (string instead of positive number) or `note` > 500 chars | `PERMISSION_DENIED` |
