import React, { useState } from 'react';
import { useRouter } from '../../context/RouterContext';
import { useAuth } from '../../context/AuthContext';
import { useDbSync } from '../../hooks/useDbSync';
import { db, TOOL_CREDIT_COSTS } from '../../services/db';
import { PackageCreditGuard } from '../../components/ui/PackageCreditGuard';
import {
  Search,
  ArrowRight,
  Sparkles,
  CreditCard,
  Lock,
  Gift,
  Crown,
} from 'lucide-react';
import { RealisticToolIcon } from '../../components/ui/RealisticIcon';
import { AnimatePresence } from 'motion/react';
import { TiltCard } from '../../components/motion/kit';

const FREE_TOOL_SLUGS = ['text-shuffler', 'duplicate-text-remover'];

export const ToolsListPage: React.FC = () => {
  useDbSync();
  const { navigate } = useRouter();
  const { user } = useAuth();
  const tools = db.getTools();
  const access = db.canUseTool(user?.id);
  const isUnlocked = access.isAdmin || access.hasUsablePackage;
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Browser & Device', 'Marketing & Outreach', 'Content Processing', 'Data Cleaning', 'Telephony & Testing', 'Email & QA'];

  const filteredTools = tools
    .filter(tool => {
      const matchSearch =
        tool.name.toLowerCase().includes(search.toLowerCase()) ||
        tool.description.toLowerCase().includes(search.toLowerCase());
      const matchCategory = selectedCategory === 'All' || tool.category === selectedCategory;
      return matchSearch && matchCategory;
    })
    // Free tools first so they are always the first thing visitors see
    .sort((a, b) => Number(FREE_TOOL_SLUGS.includes(b.slug)) - Number(FREE_TOOL_SLUGS.includes(a.slug)));

  const getToolCreditInfo = (slug: string): { label: string; isFree: boolean } => {
    switch (slug) {
      case 'user-agent-generator':
        return { label: `${TOOL_CREDIT_COSTS.UA} Credit / UA`, isFree: false };
      case 'number-generator':
        return { label: `${TOOL_CREDIT_COSTS.NUMBER} Credits / Number`, isFree: false };
      case 'mail-generator':
        return { label: `${TOOL_CREDIT_COSTS.MAIL} Credits / Email`, isFree: false };
      case 'lead-generator':
        return { label: `${TOOL_CREDIT_COSTS.LEAD} Credits / Lead`, isFree: false };
      case 'text-shuffler':
      case 'duplicate-text-remover':
        return { label: '100% Free', isFree: true };
      default:
        return { label: '1 Credit / item', isFree: false };
    }
  };

  return (
    <div className="space-y-8">
      {/* Hero banner */}
      <div className="relative overflow-hidden p-6 sm:p-9 rounded-3xl border border-blue-400/25 bg-gradient-to-br from-blue-950/80 via-slate-900/90 to-slate-950 shadow-2xl">
        <div className="absolute -top-24 -right-16 w-96 h-96 rounded-full bg-blue-500/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-10 w-80 h-80 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-bold text-blue-300 uppercase tracking-[0.2em] px-3 py-1 rounded-full bg-blue-500/15 border border-blue-400/30">
                High-Precision Suite
              </span>
              <span className="oe-free-badge text-[10px] px-2.5 py-1 rounded-full inline-flex items-center gap-1">
                <Gift className="w-3 h-3" /> 2 TOOLS FREE FOREVER
              </span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight flex items-center gap-3">
              Performance Marketing Tools
              <Sparkles className="w-6 h-6 text-amber-300" />
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Text Shuffler and Duplicate Text Remover are <strong className="text-emerald-300">100% free</strong> — no package needed. Generator tools use package credits: User Agent (1 Cr), Number (2 Cr), Mail (3 Cr), and Lead (5 Cr).
            </p>
          </div>

          <button
            onClick={() => navigate('/payment')}
            className="shrink-0 px-5 py-3.5 rounded-2xl border border-amber-400/40 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs font-bold inline-flex items-center gap-2 transition-colors cursor-pointer self-start lg:self-auto"
          >
            <CreditCard className="w-4 h-4" />
            <span className="font-mono">
              {access.isAdmin
                ? 'Admin Unlimited Mode'
                : `${access.remainingCredits.toLocaleString()} Credits · Buy / Top Up`}
            </span>
          </button>
        </div>
      </div>

      {/* Package guard for paid users / friendly upsell for free users */}
      {isUnlocked ? (
        <PackageCreditGuard
          userId={user?.id}
          requiredCredits={1}
          creditUnitLabel="UA: 1 Cr · Number: 2 Cr · Mail: 3 Cr · Lead: 5 Cr · Text Tools: Free"
        />
      ) : (
        <div className="p-5 rounded-2xl border border-blue-400/25 bg-gradient-to-r from-blue-950/60 via-slate-900/80 to-slate-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-emerald-500/15 text-emerald-300 shrink-0">
              <Gift className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="font-extrabold text-white text-sm">
                {access.planStatus === 'pending'
                  ? 'Package payment pending approval — free tools are open right now'
                  : 'Free tools are unlocked for you — go ahead and use them'}
              </h4>
              <p className="text-slate-300 text-[11px] leading-relaxed max-w-2xl">
                Text Shuffler and Duplicate Remover need no package. Take a package to also unlock the User Agent, Number, Mail and Lead generators plus the Resources hub.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigate('/payment')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-extrabold flex items-center justify-center gap-2 cursor-pointer shrink-0"
          >
            <Crown className="w-4 h-4" />
            <span>{access.planStatus === 'pending' ? 'View Payment Status' : 'Unlock All Tools'}</span>
          </button>
        </div>
      )}

      {/* Search & category filter */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-stretch sm:items-center">
        <div className="relative max-w-md w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search tools by title, function, or keyword..."
            className="w-full pl-10 pr-4 py-3 rounded-2xl border border-white/10 bg-slate-900/70 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400 transition-colors font-medium"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs p-1.5 rounded-2xl bg-slate-900/60 border border-white/5">
          {categories.slice(0, 4).map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Tools grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {filteredTools.map((tool, index) => {
            const creditInfo = getToolCreditInfo(tool.slug);
            const needsPackage = !creditInfo.isFree && !isUnlocked;
            return (
              <TiltCard
                key={tool.id}
                layout
                initial={{ opacity: 0, y: 28, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.45, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ y: -8 }}
                className={`relative p-7 rounded-3xl border flex flex-col justify-between space-y-5 shadow-xl group ${
                  creditInfo.isFree
                    ? 'border-emerald-400/30 bg-gradient-to-b from-emerald-950/30 to-slate-900/80'
                    : tool.enabled
                    ? 'border-white/10 bg-slate-900/80 hover:border-blue-400/50'
                    : 'border-white/5 bg-slate-900/40 opacity-70'
                }`}
              >
                {creditInfo.isFree && (
                  <span className="oe-free-badge absolute -top-3 left-6 text-[10px] px-3 py-1 rounded-full inline-flex items-center gap-1">
                    <Gift className="w-3 h-3" /> FREE FOR EVERYONE
                  </span>
                )}
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <RealisticToolIcon slug={tool.slug} size="lg" />
                    <div className="flex flex-col items-end gap-1.5">
                      {tool.enabled ? (
                        <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span>Ready</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full">
                          Maintenance
                        </span>
                      )}
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                          creditInfo.isFree
                            ? 'text-emerald-300 bg-emerald-500/15 border-emerald-500/30'
                            : 'text-amber-300 bg-amber-500/10 border-amber-500/20'
                        }`}
                      >
                        {creditInfo.label}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors">
                      {tool.name}
                    </h3>
                    <p className="text-[11px] font-mono font-bold text-blue-400 uppercase tracking-wider mt-0.5">
                      {tool.category}
                    </p>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{tool.description}</p>
                </div>

                <div className="pt-2">
                  <button
                    disabled={!tool.enabled}
                    onClick={() => navigate(needsPackage ? '/payment' : `/tools/${tool.slug}`)}
                    className={`w-full py-3.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                      !tool.enabled
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : needsPackage
                        ? 'border border-amber-400/40 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 cursor-pointer'
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white cursor-pointer'
                    }`}
                  >
                    {needsPackage && <Lock className="w-3.5 h-3.5" />}
                    <span>
                      {!tool.enabled
                        ? 'Currently Disabled'
                        : needsPackage
                        ? 'Take Package to Unlock'
                        : 'Open Tool Console'}
                    </span>
                    {tool.enabled && !needsPackage && (
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    )}
                  </button>
                </div>
              </TiltCard>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};
