import React, { useState } from 'react';
import { useRouter, PLATFORM_LOGO_URL } from '../../context/RouterContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { AuthBackdrop } from '../../components/motion/Extras';
import { Lock, Mail, ArrowLeft, ArrowRight, ShieldCheck } from 'lucide-react';

export const SignInPage: React.FC = () => {
  const { navigate, queryParams } = useRouter();
  const { signIn, signInWithGoogle, loading } = useAuth();
  const { showToast } = useToast();

  const redirectTarget = queryParams.get('redirect') || '/dashboard';

  const [gmail, setGmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState('');

  const handleGoogleSignIn = async () => {
    setFormError('');
    const res = await signInWithGoogle();
    if (res.success) {
      showToast('Connected with Google & synced to Cloud Database!', 'success');
      if (res.user?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate(redirectTarget === '/admin' ? '/dashboard' : redirectTarget);
      }
    } else if (res.error) {
      setFormError(res.error);
      showToast(res.error, 'error');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!gmail.trim()) {
      setFormError('Please enter your Gmail address.');
      return;
    }
    if (!password) {
      setFormError('Please enter your password.');
      return;
    }

    const res = await signIn(gmail.trim(), password);
    if (res.success) {
      showToast('Welcome back! Signed in successfully.', 'success');
      if (res.user?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate(redirectTarget === '/admin' ? '/dashboard' : redirectTarget);
      }
    } else {
      setFormError(res.error || 'Invalid Gmail or password. Please verify your credentials.');
      showToast(res.error || 'Authentication failed', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8 relative">
      <AuthBackdrop />
      {/* Top back button */}
      <div className="max-w-md w-full mx-auto">
        <button
          onClick={() => navigate('/')}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
      </div>

      {/* Main card */}
      <div className="max-w-md w-full mx-auto my-auto">
        <div className="p-8 rounded-3xl border border-slate-800 bg-slate-900/90 shadow-2xl backdrop-blur-xl space-y-6">
          <div className="text-center space-y-2">
            <div
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-2.5 cursor-pointer mb-2"
            >
              <img
                src={PLATFORM_LOGO_URL}
                alt="ONLINE EARNING IT"
                className="w-10 h-10 rounded-xl object-contain shadow-md"
              />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">Sign In to Platform</h1>
            <p className="text-xs text-slate-400">
              Sign in with Google for live Firebase Cloud sync, or use your registered Gmail & password.
            </p>
          </div>

          {formError && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              {formError}
            </div>
          )}

          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-semibold transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="#EA4335"
                d="M12 10.2v3.9h5.5c-.24 1.26-.96 2.33-2.04 3.04l3.3 2.56c1.93-1.78 3.04-4.4 3.04-7.5 0-.72-.06-1.41-.19-2.08H12z"
              />
              <path
                fill="#4285F4"
                d="M12 22c2.75 0 5.06-.91 6.75-2.47l-3.3-2.56c-.91.61-2.08.98-3.45.98-2.65 0-4.9-1.79-5.71-4.2H2.88v2.64C4.56 19.73 8.01 22 12 22z"
              />
              <path
                fill="#FBBC05"
                d="M6.29 13.75c-.2-.61-.32-1.26-.32-1.95s.12-1.34.32-1.95V7.21H2.88A9.96 9.96 0 0 0 1.8 11.8c0 1.65.4 3.21 1.08 4.59l3.41-2.64z"
              />
              <path
                fill="#34A853"
                d="M12 5.65c1.5 0 2.84.52 3.9 1.53l2.92-2.92C17.05 2.61 14.74 1.6 12 1.6 8.01 1.6 4.56 3.87 2.88 7.21l3.41 2.64C7.1 7.44 9.35 5.65 12 5.65z"
              />
            </svg>
            <span>Continue with Google (Cloud DB)</span>
          </button>

          <div className="relative flex items-center py-0.5">
            <div className="flex-grow border-t border-slate-800" />
            <span className="shrink mx-3 text-[10px] uppercase tracking-wider text-slate-500 font-medium">
              or with Gmail & Password
            </span>
            <div className="flex-grow border-t border-slate-800" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Gmail Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  value={gmail}
                  onChange={e => setGmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-medium text-slate-300">Password</label>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          <div className="text-center pt-2 border-t border-slate-800/80">
            <p className="text-xs text-slate-400">
              Don’t have an account yet?{' '}
              <button
                onClick={() => navigate('/signup')}
                className="text-blue-400 hover:text-blue-300 font-semibold"
              >
                Sign Up
              </button>
            </p>
          </div>
        </div>
      </div>

      {/* Bottom disclaimer */}
      <div className="text-center text-[11px] text-slate-600 max-w-md mx-auto">
        ONLINE EARNING IT · Secure Session Authentication
      </div>
    </div>
  );
};
