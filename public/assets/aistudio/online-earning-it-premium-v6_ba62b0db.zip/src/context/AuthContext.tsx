import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User } from '../types';
import { db } from '../services/db';
import {
  auth,
  googleProvider,
  signInWithPopup,
  firebaseSignOut,
  onAuthStateChanged,
} from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isAuthReady: boolean;
  firebaseConnected: boolean;
  quotaExceeded: boolean;
  loading: boolean;
  signIn: (gmail: string, pass: string) => Promise<{ success: boolean; user?: User; error?: string }>;
  signInWithGoogle: () => Promise<{ success: boolean; user?: User; error?: string }>;
  signUp: (fullName: string, mobile: string, gmail: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => void;
  updateProfile: (data: { fullName?: string; mobile?: string; newPassword?: string }) => Promise<{ success: boolean; error?: string }>;
  refreshUser: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => db.getCurrentUser());
  const [loading, setLoading] = useState(false);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [firebaseConnected, setFirebaseConnected] = useState(() => db.isFirebaseConnected());
  const [quotaExceeded, setQuotaExceeded] = useState(() => db.isQuotaExceeded());

  const refreshUser = useCallback(() => {
    setUser(db.getCurrentUser());
    setFirebaseConnected(db.isFirebaseConnected());
    setQuotaExceeded(db.isQuotaExceeded());
  }, []);

  useEffect(() => {
    const unsubDb = db.subscribe(() => {
      refreshUser();
    });

    const unsubAuth = onAuthStateChanged(auth, async fbUser => {
      if (fbUser && fbUser.email && fbUser.emailVerified) {
        try {
          const res = await db.authenticateWithFirebaseUser(
            fbUser.uid,
            fbUser.email,
            fbUser.displayName || fbUser.email.split('@')[0]
          );
          if (res.success && res.user) {
            setUser(res.user);
            setFirebaseConnected(true);
          } else {
            await firebaseSignOut(auth);
            db.stopFirebaseUserSync();
            setFirebaseConnected(false);
          }
        } catch (err) {
          console.error('Firebase user sync failed:', err);
          setFirebaseConnected(Boolean(auth.currentUser));
        }
      } else {
        db.stopFirebaseUserSync();
        setFirebaseConnected(false);
      }
      setIsAuthReady(true);
    });

    return () => {
      unsubDb();
      unsubAuth();
    };
  }, [refreshUser]);

  const signIn = async (gmail: string, pass: string) => {
    setLoading(true);
    try {
      const res = await db.authenticate(gmail, pass);
      if (res.success && res.user) {
        setUser(res.user);
        return { success: true, user: res.user };
      }
      return { success: false, error: res.error || 'Authentication failed' };
    } catch {
      return { success: false, error: 'An unexpected error occurred during sign in.' };
    } finally {
      setLoading(false);
    }
  };

  const signInWithGoogle = async () => {
    setLoading(true);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const fbUser = cred.user;
      if (!fbUser.email) {
        return { success: false, error: 'No email returned from Google account.' };
      }
      const res = await db.authenticateWithFirebaseUser(
        fbUser.uid,
        fbUser.email,
        fbUser.displayName || fbUser.email.split('@')[0]
      );
      if (res.success && res.user) {
        setUser(res.user);
        setFirebaseConnected(true);
        return { success: true, user: res.user };
      }
      await firebaseSignOut(auth);
      return { success: false, error: res.error || 'Google authentication failed.' };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Google Sign-In failed.';
      if (message.includes('popup-closed-by-user')) {
        return { success: false, error: 'Sign-in popup was closed before completion.' };
      }
      return { success: false, error: message };
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (fullName: string, mobile: string, gmail: string, pass: string) => {
    setLoading(true);
    try {
      const res = await db.registerUser(fullName, mobile, gmail, pass);
      if (res.success && res.user) {
        db.setCurrentUser(res.user);
        setUser(res.user);
        return { success: true };
      }
      return { success: false, error: res.error || 'Registration failed' };
    } catch {
      return { success: false, error: 'An unexpected error occurred during registration.' };
    } finally {
      setLoading(false);
    }
  };

  const signOut = () => {
    db.stopFirebaseUserSync();
    void firebaseSignOut(auth);
    db.setCurrentUser(null);
    setUser(null);
    setFirebaseConnected(false);
  };

  const updateProfile = async (data: { fullName?: string; mobile?: string; newPassword?: string }) => {
    if (!user) return { success: false, error: 'Not authenticated' };
    const res = await db.updateUserProfile(user.id, data);
    if (res.success) {
      refreshUser();
    }
    return res;
  };

  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isAdmin,
        isAuthReady,
        firebaseConnected,
        quotaExceeded,
        loading,
        signIn,
        signInWithGoogle,
        signUp,
        signOut,
        updateProfile,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
