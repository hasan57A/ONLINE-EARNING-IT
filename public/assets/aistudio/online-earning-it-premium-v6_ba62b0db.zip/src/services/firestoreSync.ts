import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  deleteDoc,
  where,
  writeBatch,
  serverTimestamp,
  Unsubscribe,
} from 'firebase/firestore';
import {
  auth,
  firestoreDb,
  OperationType,
  handleFirestoreError,
  timestampToIso,
  clampStr,
  sanitizeDocId,
  isQuotaExceededError,
} from '../lib/firebase';
import {
  User,
  ToolItem,
  UserAgentEntry,
  LeadEntry,
  NumberEntry,
  MailEntry,
  CpaNetwork,
  ProxySite,
  AntidetectBrowser,
  SupportTicket,
  SupportChatMessage,
  UsageHistoryEntry,
  SavedResult,
  WebsiteContent,
  PaymentGatewaySettings,
  PaymentRequest,
} from '../types';

export interface SyncCallbacks {
  onTools: (tools: ToolItem[]) => void;
  onWebsiteContent: (content: WebsiteContent) => void;
  onPaymentGateways: (settings: PaymentGatewaySettings) => void;
  onCpaNetworks: (items: CpaNetwork[]) => void;
  onProxySites: (items: ProxySite[]) => void;
  onAntidetectBrowsers: (items: AntidetectBrowser[]) => void;
  onUsers: (users: User[], replaceAll: boolean) => void;
  onUaPool: (items: UserAgentEntry[]) => void;
  onLeadsPool: (items: LeadEntry[]) => void;
  onNumbersPool: (items: NumberEntry[]) => void;
  onMailsPool: (items: MailEntry[]) => void;
  onPaymentRequests: (items: PaymentRequest[]) => void;
  onUsageHistory: (items: UsageHistoryEntry[]) => void;
  onSavedResults: (items: SavedResult[]) => void;
  onSupportTickets: (items: SupportTicket[]) => void;
  onQuotaExceeded?: () => void;
}

class FirestoreSyncService {
  private publicUnsubs: Unsubscribe[] = [];
  private userUnsubs: Unsubscribe[] = [];
  private ticketMsgUnsubs: Map<string, Unsubscribe> = new Map();
  private ticketMessagesCache: Map<string, SupportChatMessage[]> = new Map();
  private activeTicketHeaders: Map<string, Omit<SupportTicket, 'messages'>> = new Map();
  private callbacks: SyncCallbacks | null = null;
  private syncedUid: string | null = null;

  public registerCallbacks(cb: SyncCallbacks) {
    this.callbacks = cb;
  }

  private emitTicketsMerged() {
    if (!this.callbacks) return;
    const merged: SupportTicket[] = Array.from(this.activeTicketHeaders.values())
      .map(header => ({
        ...header,
        messages: this.ticketMessagesCache.get(header.id) || [],
      }))
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    this.callbacks.onSupportTickets(merged);
  }

  private handleSnapshotError(error: unknown, op: OperationType, path: string) {
    if (isQuotaExceededError(error)) {
      this.callbacks?.onQuotaExceeded?.();
    }
    handleFirestoreError(error, op, path);
  }

  public startPublicListeners() {
    this.stopPublicListeners();

    // 1. Tools catalog (query matches allow list: resource.data.enabled in [true, false])
    this.publicUnsubs.push(
      onSnapshot(
        query(collection(firestoreDb, 'tools'), where('enabled', 'in', [true, false])),
        snap => {
          if (!snap.empty && this.callbacks) {
            const list: ToolItem[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                name: String(data.name || ''),
                slug: String(data.slug || ''),
                description: String(data.description || ''),
                category: String(data.category || ''),
                enabled: Boolean(data.enabled),
                iconName: String(data.iconName || 'Wrench'),
              };
            });
            this.callbacks.onTools(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'tools')
      )
    );

    // 2. Public Website Content
    this.publicUnsubs.push(
      onSnapshot(
        doc(firestoreDb, 'siteConfig', 'websiteContent'),
        snap => {
          if (snap.exists() && this.callbacks) {
            const data = snap.data();
            this.callbacks.onWebsiteContent({
              heroTitle: String(data.heroTitle || ''),
              heroHighlight: String(data.heroHighlight || ''),
              heroDescription: String(data.heroDescription || ''),
              aboutTitle: String(data.aboutTitle || ''),
              aboutText: String(data.aboutText || ''),
              contactEmail: String(data.contactEmail || ''),
              contactPhone: String(data.contactPhone || ''),
              contactTelegram: String(data.contactTelegram || ''),
              socialLinks: {
                facebook: String(data.socialLinks?.facebook || ''),
                instagram: String(data.socialLinks?.instagram || ''),
                tiktok: String(data.socialLinks?.tiktok || ''),
                telegram: String(data.socialLinks?.telegram || ''),
              },
              footerDescription: String(data.footerDescription || ''),
            });
          }
        },
        err => this.handleSnapshotError(err, OperationType.GET, 'siteConfig/websiteContent')
      )
    );
  }

  public stopPublicListeners() {
    this.publicUnsubs.forEach(u => u());
    this.publicUnsubs = [];
  }

  public stopUserListeners() {
    this.userUnsubs.forEach(u => u());
    this.userUnsubs = [];
    this.ticketMsgUnsubs.forEach(u => u());
    this.ticketMsgUnsubs.clear();
    this.ticketMessagesCache.clear();
    this.activeTicketHeaders.clear();
    this.syncedUid = null;
  }

  public startUserListeners(uid: string, isAdmin: boolean) {
    if (!auth.currentUser || !auth.currentUser.emailVerified) return;
    if (this.syncedUid === uid) return;

    this.stopUserListeners();
    this.syncedUid = uid;

    // 0. Curated Resource Directories (authenticated users only)
    const cpaQ = isAdmin
      ? collection(firestoreDb, 'cpaNetworks')
      : query(collection(firestoreDb, 'cpaNetworks'), where('name', '>=', ''));
    this.userUnsubs.push(
      onSnapshot(
        cpaQ,
        snap => {
          if (this.callbacks && !snap.empty) {
            const list: CpaNetwork[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                name: String(data.name || ''),
                type: String(data.type || ''),
                minPayment: String(data.minPayment || ''),
                description: String(data.description || ''),
                joinUrl: String(data.joinUrl || ''),
              };
            });
            this.callbacks.onCpaNetworks(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'cpaNetworks')
      )
    );

    const proxyQ = isAdmin
      ? collection(firestoreDb, 'proxySites')
      : query(collection(firestoreDb, 'proxySites'), where('name', '>=', ''));
    this.userUnsubs.push(
      onSnapshot(
        proxyQ,
        snap => {
          if (this.callbacks && !snap.empty) {
            const list: ProxySite[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                name: String(data.name || ''),
                validity: String(data.validity || ''),
                traffic: String(data.traffic || ''),
                price: String(data.price || ''),
                buyUrl: String(data.buyUrl || ''),
              };
            });
            this.callbacks.onProxySites(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'proxySites')
      )
    );

    const adbQ = isAdmin
      ? collection(firestoreDb, 'antidetectBrowsers')
      : query(collection(firestoreDb, 'antidetectBrowsers'), where('name', '>=', ''));
    this.userUnsubs.push(
      onSnapshot(
        adbQ,
        snap => {
          if (this.callbacks && !snap.empty) {
            const list: AntidetectBrowser[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                name: String(data.name || ''),
                description: String(data.description || ''),
                downloadUrl: String(data.downloadUrl || ''),
              };
            });
            this.callbacks.onAntidetectBrowsers(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'antidetectBrowsers')
      )
    );

    // 1. Payment Gateway Settings
    this.userUnsubs.push(
      onSnapshot(
        doc(firestoreDb, 'siteConfig', 'paymentGateways'),
        snap => {
          if (snap.exists() && this.callbacks) {
            const data = snap.data();
            this.callbacks.onPaymentGateways({
              bkashNumber: String(data.bkashNumber || ''),
              bkashType: String(data.bkashType || ''),
              nagadNumber: String(data.nagadNumber || ''),
              nagadType: String(data.nagadType || ''),
              rocketNumber: String(data.rocketNumber || ''),
              rocketType: String(data.rocketType || ''),
              binancePayId: String(data.binancePayId || ''),
              binanceTrc20Address: String(data.binanceTrc20Address || ''),
              binanceBep20Address: String(data.binanceBep20Address || ''),
              instructionsNote: String(data.instructionsNote || ''),
            });
          }
        },
        err => this.handleSnapshotError(err, OperationType.GET, 'siteConfig/paymentGateways')
      )
    );

    // 2. Users
    if (isAdmin) {
      this.userUnsubs.push(
        onSnapshot(
          collection(firestoreDb, 'users'),
          snap => {
            if (this.callbacks) {
              const list: User[] = snap.docs.map(d => this.mapUserDoc(d.id, d.data()));
              this.callbacks.onUsers(list, true);
            }
          },
          err => this.handleSnapshotError(err, OperationType.LIST, 'users')
        )
      );
    } else {
      this.userUnsubs.push(
        onSnapshot(
          doc(firestoreDb, 'users', uid),
          snap => {
            if (snap.exists() && this.callbacks) {
              this.callbacks.onUsers([this.mapUserDoc(snap.id, snap.data())], false);
            }
          },
          err => this.handleSnapshotError(err, OperationType.GET, `users/${uid}`)
        )
      );
    }

    // 3. Generator Pools (Admin sees all; regular verified user sees unused records)
    const uaQ = isAdmin
      ? collection(firestoreDb, 'uaPool')
      : query(collection(firestoreDb, 'uaPool'), where('used', '==', false));
    this.userUnsubs.push(
      onSnapshot(
        uaQ,
        snap => {
          if (this.callbacks) {
            const list: UserAgentEntry[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                device: data.device,
                browser: data.browser,
                inAppBrowser: data.inAppBrowser,
                country: String(data.country || ''),
                userAgentString: String(data.userAgentString || ''),
                used: Boolean(data.used),
                usedBy: data.usedBy ? String(data.usedBy) : undefined,
                usedAt: data.usedAt ? timestampToIso(data.usedAt) : undefined,
                createdAt: timestampToIso(data.createdAt),
              };
            });
            this.callbacks.onUaPool(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'uaPool')
      )
    );

    const leadsQ = isAdmin
      ? collection(firestoreDb, 'leadsPool')
      : query(collection(firestoreDb, 'leadsPool'), where('used', '==', false));
    this.userUnsubs.push(
      onSnapshot(
        leadsQ,
        snap => {
          if (this.callbacks) {
            const list: LeadEntry[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                fullName: String(data.fullName || ''),
                gender: data.gender,
                gmail: String(data.gmail || ''),
                phoneNumber: String(data.phoneNumber || ''),
                country: String(data.country || ''),
                used: Boolean(data.used),
                usedBy: data.usedBy ? String(data.usedBy) : undefined,
                usedAt: data.usedAt ? timestampToIso(data.usedAt) : undefined,
                createdAt: timestampToIso(data.createdAt),
              };
            });
            this.callbacks.onLeadsPool(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'leadsPool')
      )
    );

    const numbersQ = isAdmin
      ? collection(firestoreDb, 'numbersPool')
      : query(collection(firestoreDb, 'numbersPool'), where('used', '==', false));
    this.userUnsubs.push(
      onSnapshot(
        numbersQ,
        snap => {
          if (this.callbacks) {
            const list: NumberEntry[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                country: String(data.country || ''),
                phoneNumber: String(data.phoneNumber || ''),
                used: Boolean(data.used),
                usedBy: data.usedBy ? String(data.usedBy) : undefined,
                usedAt: data.usedAt ? timestampToIso(data.usedAt) : undefined,
                createdAt: timestampToIso(data.createdAt),
              };
            });
            this.callbacks.onNumbersPool(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'numbersPool')
      )
    );

    const mailsQ = isAdmin
      ? collection(firestoreDb, 'mailsPool')
      : query(collection(firestoreDb, 'mailsPool'), where('used', '==', false));
    this.userUnsubs.push(
      onSnapshot(
        mailsQ,
        snap => {
          if (this.callbacks) {
            const list: MailEntry[] = snap.docs.map(d => {
              const data = d.data();
              return {
                id: String(data.id || d.id),
                country: String(data.country || ''),
                email: String(data.email || ''),
                used: Boolean(data.used),
                usedBy: data.usedBy ? String(data.usedBy) : undefined,
                usedAt: data.usedAt ? timestampToIso(data.usedAt) : undefined,
                createdAt: timestampToIso(data.createdAt),
              };
            });
            this.callbacks.onMailsPool(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'mailsPool')
      )
    );

    // 4. Payment Requests
    const payQ = isAdmin
      ? collection(firestoreDb, 'paymentRequests')
      : query(collection(firestoreDb, 'paymentRequests'), where('userId', '==', uid));
    this.userUnsubs.push(
      onSnapshot(
        payQ,
        snap => {
          if (this.callbacks) {
            const list: PaymentRequest[] = snap.docs
              .map(d => {
                const data = d.data();
                return {
                  id: String(data.id || d.id),
                  userId: String(data.userId || ''),
                  userName: String(data.userName || ''),
                  userEmail: String(data.userEmail || ''),
                  packageId: String(data.packageId || ''),
                  packageName: String(data.packageName || ''),
                  packageCredits: data.packageCredits !== undefined ? Number(data.packageCredits) : undefined,
                  method: data.method,
                  currency: data.currency,
                  amount: Number(data.amount || 0),
                  senderAccount: String(data.senderAccount || ''),
                  transactionId: String(data.transactionId || ''),
                  note: data.note ? String(data.note) : '',
                  status: data.status,
                  adminNote: data.adminNote ? String(data.adminNote) : undefined,
                  reviewedBy: data.reviewedBy ? String(data.reviewedBy) : undefined,
                  reviewedAt: data.reviewedAt ? timestampToIso(data.reviewedAt) : undefined,
                  createdAt: timestampToIso(data.createdAt),
                };
              })
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            this.callbacks.onPaymentRequests(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'paymentRequests')
      )
    );

    // 5. Usage History
    const histQ = isAdmin
      ? collection(firestoreDb, 'usageHistory')
      : query(collection(firestoreDb, 'usageHistory'), where('userId', '==', uid));
    this.userUnsubs.push(
      onSnapshot(
        histQ,
        snap => {
          if (this.callbacks) {
            const list: UsageHistoryEntry[] = snap.docs
              .map(d => {
                const data = d.data();
                return {
                  id: String(data.id || d.id),
                  userId: String(data.userId || ''),
                  toolSlug: String(data.toolSlug || ''),
                  toolName: String(data.toolName || ''),
                  date: String(data.date || ''),
                  time: String(data.time || ''),
                  resultCount: Number(data.resultCount || 0),
                  status: data.status,
                  summary: data.summary ? String(data.summary) : undefined,
                };
              })
              .sort((a, b) => b.id.localeCompare(a.id));
            this.callbacks.onUsageHistory(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'usageHistory')
      )
    );

    // 6. Saved Results
    const savedQ = isAdmin
      ? collection(firestoreDb, 'savedResults')
      : query(collection(firestoreDb, 'savedResults'), where('userId', '==', uid));
    this.userUnsubs.push(
      onSnapshot(
        savedQ,
        snap => {
          if (this.callbacks) {
            const list: SavedResult[] = snap.docs
              .map(d => {
                const data = d.data();
                return {
                  id: String(data.id || d.id),
                  userId: String(data.userId || ''),
                  toolSlug: String(data.toolSlug || ''),
                  toolName: String(data.toolName || ''),
                  title: String(data.title || ''),
                  resultsText: String(data.resultsText || ''),
                  count: Number(data.count || 0),
                  savedDate: String(data.savedDate || ''),
                };
              })
              .sort((a, b) => b.id.localeCompare(a.id));
            this.callbacks.onSavedResults(list);
          }
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'savedResults')
      )
    );

    // 7. Support Tickets & Message Subcollections
    const ticketsQ = isAdmin
      ? collection(firestoreDb, 'supportTickets')
      : query(collection(firestoreDb, 'supportTickets'), where('userId', '==', uid));
    this.userUnsubs.push(
      onSnapshot(
        ticketsQ,
        snap => {
          const currentTicketIds = new Set<string>();
          this.activeTicketHeaders.clear();

          snap.docs.forEach(d => {
            const data = d.data();
            const tid = String(data.id || d.id);
            currentTicketIds.add(tid);
            this.activeTicketHeaders.set(tid, {
              id: tid,
              userId: String(data.userId || ''),
              userName: String(data.userName || ''),
              userEmail: String(data.userEmail || ''),
              subject: String(data.subject || ''),
              status: data.status,
              createdAt: timestampToIso(data.createdAt),
              updatedAt: timestampToIso(data.updatedAt),
            });

            if (!this.ticketMsgUnsubs.has(tid)) {
              const msgsRef = collection(firestoreDb, 'supportTickets', tid, 'messages');
              const msgsQuery = isAdmin ? msgsRef : query(msgsRef, where('ticketOwnerId', '==', uid));
              const unsubMsg = onSnapshot(
                msgsQuery,
                msgSnap => {
                  const msgs: SupportChatMessage[] = msgSnap.docs
                    .map(md => {
                      const mdata = md.data();
                      return {
                        id: String(mdata.id || md.id),
                        sender: mdata.sender,
                        senderName: String(mdata.senderName || ''),
                        text: String(mdata.text || ''),
                        timestamp: String(mdata.timestamp || ''),
                      };
                    })
                    .sort((a, b) => a.id.localeCompare(b.id));
                  this.ticketMessagesCache.set(tid, msgs);
                  this.emitTicketsMerged();
                },
                err => this.handleSnapshotError(err, OperationType.LIST, `supportTickets/${tid}/messages`)
              );
              this.ticketMsgUnsubs.set(tid, unsubMsg);
            }
          });

          // Clean up stale ticket message listeners
          Array.from(this.ticketMsgUnsubs.keys()).forEach(tid => {
            if (!currentTicketIds.has(tid)) {
              this.ticketMsgUnsubs.get(tid)?.();
              this.ticketMsgUnsubs.delete(tid);
              this.ticketMessagesCache.delete(tid);
            }
          });

          this.emitTicketsMerged();
        },
        err => this.handleSnapshotError(err, OperationType.LIST, 'supportTickets')
      )
    );
  }

  private mapUserDoc(docId: string, data: Record<string, unknown>): User {
    return {
      id: String(data.id || docId),
      fullName: String(data.fullName || ''),
      mobile: String(data.mobile || ''),
      gmail: String(data.gmail || ''),
      passwordHash: '',
      salt: '',
      role: data.role === 'admin' ? 'admin' : 'user',
      status: data.status === 'deactivated' ? 'deactivated' : 'active',
      plan: data.plan ? String(data.plan) : undefined,
      planStatus: (data.planStatus as User['planStatus']) || 'none',
      credits: typeof data.credits === 'number' ? data.credits : 0,
      planUpdatedAt: data.planUpdatedAt ? timestampToIso(data.planUpdatedAt) : undefined,
      createdAt: timestampToIso(data.createdAt),
      updatedAt: data.updatedAt ? timestampToIso(data.updatedAt) : undefined,
    };
  }

  // --- Auth User Provisioning in Firestore ---
  public async syncFirebaseAuthenticatedUser(
    uid: string,
    email: string,
    displayName: string,
    adminEmails: string[]
  ): Promise<User> {
    const cleanEmail = email.trim().toLowerCase();
    const isOwnerAdmin = adminEmails.includes(cleanEmail);
    const userPath = `users/${uid}`;

    try {
      if (isOwnerAdmin) {
        const adminRef = doc(firestoreDb, 'admins', uid);
        const adminSnap = await getDoc(adminRef);
        if (!adminSnap.exists()) {
          await setDoc(adminRef, {
            uid: sanitizeDocId(uid),
            email: clampStr(cleanEmail, 160),
            role: 'admin',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      }

      const userRef = doc(firestoreDb, 'users', uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        const newPayload: Record<string, unknown> = {
          id: sanitizeDocId(uid),
          fullName: clampStr(displayName.trim() || cleanEmail.split('@')[0], 120),
          mobile: '',
          gmail: clampStr(cleanEmail, 160),
          role: isOwnerAdmin ? 'admin' : 'user',
          status: 'active',
          planStatus: 'none',
          credits: 0,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        await setDoc(userRef, newPayload);
        const freshSnap = await getDoc(userRef);
        return this.mapUserDoc(uid, freshSnap.data() || newPayload);
      }

      const existingData = userSnap.data();
      if (isOwnerAdmin && (existingData.role !== 'admin' || existingData.status !== 'active')) {
        await updateDoc(userRef, {
          role: 'admin',
          status: 'active',
          updatedAt: serverTimestamp(),
        });
        const updatedSnap = await getDoc(userRef);
        return this.mapUserDoc(uid, updatedSnap.data() || existingData);
      }

      return this.mapUserDoc(uid, existingData);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, userPath);
    }
  }

  public async bootstrapAdminDefaults(defaults: {
    tools: ToolItem[];
    websiteContent: WebsiteContent;
    paymentGateways: PaymentGatewaySettings;
  }) {
    if (!auth.currentUser) return;
    try {
      const toolsSnap = await getDocs(collection(firestoreDb, 'tools'));
      if (toolsSnap.empty) {
        const batch = writeBatch(firestoreDb);
        defaults.tools.forEach(t => {
          const id = sanitizeDocId(t.id);
          batch.set(doc(firestoreDb, 'tools', id), {
            id,
            name: clampStr(t.name, 100),
            slug: clampStr(t.slug, 100),
            description: clampStr(t.description, 500),
            category: clampStr(t.category, 80),
            enabled: Boolean(t.enabled),
            iconName: clampStr(t.iconName, 50),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        });
        await batch.commit();
      }

      const wcRef = doc(firestoreDb, 'siteConfig', 'websiteContent');
      const wcSnap = await getDoc(wcRef);
      if (!wcSnap.exists()) {
        await setDoc(wcRef, {
          ...this.sanitizeWebsiteContent(defaults.websiteContent),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      const pgRef = doc(firestoreDb, 'siteConfig', 'paymentGateways');
      const pgSnap = await getDoc(pgRef);
      if (!pgSnap.exists()) {
        await setDoc(pgRef, {
          ...this.sanitizePaymentGateways(defaults.paymentGateways),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'siteConfig');
    }
  }

  // --- Writes ---
  public async syncUserStatus(userId: string, status: 'active' | 'deactivated') {
    if (!auth.currentUser) return;
    const path = `users/${userId}`;
    try {
      const ref = doc(firestoreDb, 'users', userId);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        await updateDoc(ref, { status, updatedAt: serverTimestamp() });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  public async syncUserProfile(userId: string, data: { fullName?: string; mobile?: string }) {
    if (!auth.currentUser) return;
    const path = `users/${userId}`;
    try {
      const ref = doc(firestoreDb, 'users', userId);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const patch: Record<string, unknown> = { updatedAt: serverTimestamp() };
        if (data.fullName !== undefined) patch.fullName = clampStr(data.fullName.trim(), 120) || 'User';
        if (data.mobile !== undefined) patch.mobile = clampStr(data.mobile.trim(), 40);
        await updateDoc(ref, patch);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  public async syncUserCreditsUpdate(
    userId: string,
    credits: number,
    planPatch?: { plan?: string; planStatus?: 'none' | 'pending' | 'active' }
  ) {
    if (!auth.currentUser) return;
    const path = `users/${userId}`;
    try {
      const ref = doc(firestoreDb, 'users', sanitizeDocId(userId));
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const patch: Record<string, unknown> = {
          credits: Math.max(0, Math.min(10000000, Math.floor(Number(credits) || 0))),
          updatedAt: serverTimestamp(),
        };
        if (planPatch?.planStatus !== undefined) {
          patch.planStatus = planPatch.planStatus;
        }
        if (planPatch?.plan !== undefined) {
          patch.plan = clampStr(planPatch.plan, 80);
          patch.planUpdatedAt = serverTimestamp();
        }
        await updateDoc(ref, patch);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  public async syncTool(tool: ToolItem) {
    if (!auth.currentUser) return;
    const id = sanitizeDocId(tool.id);
    const path = `tools/${id}`;
    try {
      const ref = doc(firestoreDb, 'tools', id);
      const snap = await getDoc(ref);
      const payload = {
        id,
        name: clampStr(tool.name, 100),
        slug: clampStr(tool.slug, 100),
        description: clampStr(tool.description, 500),
        category: clampStr(tool.category, 80),
        enabled: Boolean(tool.enabled),
        iconName: clampStr(tool.iconName, 50),
        updatedAt: serverTimestamp(),
      };
      if (snap.exists()) {
        await updateDoc(ref, payload);
      } else {
        await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  public async syncPoolAdd(
    collectionName: 'uaPool' | 'leadsPool' | 'numbersPool' | 'mailsPool',
    items: Array<UserAgentEntry | LeadEntry | NumberEntry | MailEntry>
  ) {
    if (!auth.currentUser || items.length === 0) return;
    try {
      const CHUNK = 400;
      for (let i = 0; i < items.length; i += CHUNK) {
        const slice = items.slice(i, i + CHUNK);
        const batch = writeBatch(firestoreDb);
        for (const item of slice) {
          const id = sanitizeDocId(item.id);
          const ref = doc(firestoreDb, collectionName, id);
          if (collectionName === 'uaPool') {
            const u = item as UserAgentEntry;
            batch.set(ref, {
              id,
              device: u.device,
              browser: u.browser,
              inAppBrowser: u.inAppBrowser,
              country: clampStr(u.country, 100),
              userAgentString: clampStr(u.userAgentString, 1000),
              used: false,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          } else if (collectionName === 'leadsPool') {
            const l = item as LeadEntry;
            batch.set(ref, {
              id,
              fullName: clampStr(l.fullName, 120),
              gender: l.gender,
              gmail: clampStr(l.gmail, 160),
              phoneNumber: clampStr(l.phoneNumber, 40),
              country: clampStr(l.country, 100),
              used: false,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          } else if (collectionName === 'numbersPool') {
            const n = item as NumberEntry;
            batch.set(ref, {
              id,
              country: clampStr(n.country, 100),
              phoneNumber: clampStr(n.phoneNumber, 40),
              used: false,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          } else {
            const m = item as MailEntry;
            batch.set(ref, {
              id,
              country: clampStr(m.country, 100),
              email: clampStr(m.email, 160),
              used: false,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          }
        }
        await batch.commit();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, collectionName);
    }
  }

  public async syncPoolConsume(
    collectionName: 'uaPool' | 'leadsPool' | 'numbersPool' | 'mailsPool',
    docIds: string[]
  ) {
    if (!auth.currentUser || docIds.length === 0) return;
    const uid = auth.currentUser.uid;
    try {
      const CHUNK = 400;
      for (let i = 0; i < docIds.length; i += CHUNK) {
        const slice = docIds.slice(i, i + CHUNK);
        const batch = writeBatch(firestoreDb);
        for (const rawId of slice) {
          const id = sanitizeDocId(rawId);
          batch.update(doc(firestoreDb, collectionName, id), {
            used: true,
            usedBy: uid,
            usedAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
        await batch.commit();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, collectionName);
    }
  }

  public async syncPoolDelete(
    collectionName: 'uaPool' | 'leadsPool' | 'numbersPool' | 'mailsPool',
    docIds: string[]
  ) {
    if (!auth.currentUser || docIds.length === 0) return;
    try {
      const CHUNK = 400;
      for (let i = 0; i < docIds.length; i += CHUNK) {
        const slice = docIds.slice(i, i + CHUNK);
        const batch = writeBatch(firestoreDb);
        for (const rawId of slice) {
          batch.delete(doc(firestoreDb, collectionName, sanitizeDocId(rawId)));
        }
        await batch.commit();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, collectionName);
    }
  }

  public async syncResourceUpsert(
    collectionName: 'cpaNetworks' | 'proxySites' | 'antidetectBrowsers',
    item: CpaNetwork | ProxySite | AntidetectBrowser
  ) {
    if (!auth.currentUser) return;
    const id = sanitizeDocId(item.id);
    const path = `${collectionName}/${id}`;
    try {
      const ref = doc(firestoreDb, collectionName, id);
      const snap = await getDoc(ref);
      let payload: Record<string, unknown>;
      if (collectionName === 'cpaNetworks') {
        const c = item as CpaNetwork;
        payload = {
          id,
          name: clampStr(c.name, 120),
          type: clampStr(c.type, 120),
          minPayment: clampStr(c.minPayment, 80),
          description: clampStr(c.description, 800),
          joinUrl: clampStr(c.joinUrl, 400),
          updatedAt: serverTimestamp(),
        };
      } else if (collectionName === 'proxySites') {
        const p = item as ProxySite;
        payload = {
          id,
          name: clampStr(p.name, 120),
          validity: clampStr(p.validity, 120),
          traffic: clampStr(p.traffic, 160),
          price: clampStr(p.price, 80),
          buyUrl: clampStr(p.buyUrl, 400),
          updatedAt: serverTimestamp(),
        };
      } else {
        const b = item as AntidetectBrowser;
        payload = {
          id,
          name: clampStr(b.name, 120),
          description: clampStr(b.description, 800),
          downloadUrl: clampStr(b.downloadUrl, 400),
          updatedAt: serverTimestamp(),
        };
      }

      if (snap.exists()) {
        await updateDoc(ref, payload);
      } else {
        await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  public async syncResourceDelete(
    collectionName: 'cpaNetworks' | 'proxySites' | 'antidetectBrowsers',
    id: string
  ) {
    if (!auth.currentUser) return;
    const cleanId = sanitizeDocId(id);
    try {
      await deleteDoc(doc(firestoreDb, collectionName, cleanId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${collectionName}/${cleanId}`);
    }
  }

  public async syncUsageHistoryAdd(entry: UsageHistoryEntry) {
    if (!auth.currentUser) return;
    const id = sanitizeDocId(entry.id);
    const path = `usageHistory/${id}`;
    try {
      const payload: Record<string, unknown> = {
        id,
        userId: auth.currentUser.uid,
        toolSlug: clampStr(entry.toolSlug, 100),
        toolName: clampStr(entry.toolName, 100),
        date: clampStr(entry.date, 30),
        time: clampStr(entry.time, 30),
        resultCount: Math.max(0, Math.min(10000, Number(entry.resultCount || 0))),
        status: entry.status === 'Failed' ? 'Failed' : 'Success',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      if (entry.summary) {
        payload.summary = clampStr(entry.summary, 300);
      }
      await setDoc(doc(firestoreDb, 'usageHistory', id), payload);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  public async syncUsageHistoryClear(ids: string[]) {
    if (!auth.currentUser || ids.length === 0) return;
    try {
      const CHUNK = 400;
      for (let i = 0; i < ids.length; i += CHUNK) {
        const batch = writeBatch(firestoreDb);
        ids.slice(i, i + CHUNK).forEach(id => {
          batch.delete(doc(firestoreDb, 'usageHistory', sanitizeDocId(id)));
        });
        await batch.commit();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'usageHistory');
    }
  }

  public async syncSavedResultAdd(entry: SavedResult) {
    if (!auth.currentUser) return;
    const id = sanitizeDocId(entry.id);
    const path = `savedResults/${id}`;
    try {
      await setDoc(doc(firestoreDb, 'savedResults', id), {
        id,
        userId: auth.currentUser.uid,
        toolSlug: clampStr(entry.toolSlug, 100),
        toolName: clampStr(entry.toolName, 100),
        title: clampStr(entry.title, 160) || 'Saved Export',
        resultsText: clampStr(entry.resultsText, 100000),
        count: Math.max(0, Math.min(10000, Number(entry.count || 0))),
        savedDate: clampStr(entry.savedDate, 60),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  public async syncSavedResultDelete(id: string) {
    if (!auth.currentUser) return;
    const cleanId = sanitizeDocId(id);
    try {
      await deleteDoc(doc(firestoreDb, 'savedResults', cleanId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `savedResults/${cleanId}`);
    }
  }

  public async syncSupportTicketCreate(ticket: SupportTicket) {
    if (!auth.currentUser) return;
    const tid = sanitizeDocId(ticket.id);
    const uid = auth.currentUser.uid;
    try {
      await setDoc(doc(firestoreDb, 'supportTickets', tid), {
        id: tid,
        userId: uid,
        userName: clampStr(ticket.userName, 120) || 'User',
        userEmail: clampStr(ticket.userEmail, 160),
        subject: clampStr(ticket.subject, 200) || 'Support Request',
        status: 'open',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      const firstMsg = ticket.messages[0];
      if (firstMsg) {
        const mid = sanitizeDocId(firstMsg.id);
        await setDoc(doc(firestoreDb, 'supportTickets', tid, 'messages', mid), {
          id: mid,
          ticketId: tid,
          ticketOwnerId: uid,
          sender: 'user',
          senderUid: uid,
          senderName: clampStr(firstMsg.senderName, 120) || 'User',
          text: clampStr(firstMsg.text, 2000),
          timestamp: clampStr(firstMsg.timestamp, 60),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `supportTickets/${tid}`);
    }
  }

  public async syncSupportTicketReply(
    ticketId: string,
    ticketOwnerId: string,
    msg: SupportChatMessage,
    nextStatus: 'open' | 'replied' | 'closed'
  ) {
    if (!auth.currentUser) return;
    const tid = sanitizeDocId(ticketId);
    const mid = sanitizeDocId(msg.id);
    try {
      await setDoc(doc(firestoreDb, 'supportTickets', tid, 'messages', mid), {
        id: mid,
        ticketId: tid,
        ticketOwnerId: sanitizeDocId(ticketOwnerId),
        sender: msg.sender,
        senderUid: auth.currentUser.uid,
        senderName: clampStr(msg.senderName, 120) || 'User',
        text: clampStr(msg.text, 2000),
        timestamp: clampStr(msg.timestamp, 60),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(firestoreDb, 'supportTickets', tid), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `supportTickets/${tid}/messages/${mid}`);
    }
  }

  public async syncSupportTicketStatus(ticketId: string, status: 'open' | 'replied' | 'closed') {
    if (!auth.currentUser) return;
    const tid = sanitizeDocId(ticketId);
    try {
      await updateDoc(doc(firestoreDb, 'supportTickets', tid), {
        status,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `supportTickets/${tid}`);
    }
  }

  private sanitizeWebsiteContent(c: WebsiteContent) {
    return {
      heroTitle: clampStr(c.heroTitle, 250),
      heroHighlight: clampStr(c.heroHighlight, 200),
      heroDescription: clampStr(c.heroDescription, 1000),
      aboutTitle: clampStr(c.aboutTitle, 200),
      aboutText: clampStr(c.aboutText, 2000),
      contactEmail: clampStr(c.contactEmail, 160),
      contactPhone: clampStr(c.contactPhone, 60),
      contactTelegram: clampStr(c.contactTelegram, 100),
      socialLinks: {
        facebook: clampStr(c.socialLinks?.facebook, 300),
        instagram: clampStr(c.socialLinks?.instagram, 300),
        tiktok: clampStr(c.socialLinks?.tiktok, 300),
        telegram: clampStr(c.socialLinks?.telegram, 300),
      },
      footerDescription: clampStr(c.footerDescription, 600),
    };
  }

  public async syncWebsiteContent(content: WebsiteContent) {
    if (!auth.currentUser) return;
    const path = 'siteConfig/websiteContent';
    try {
      const ref = doc(firestoreDb, 'siteConfig', 'websiteContent');
      const snap = await getDoc(ref);
      const payload = {
        ...this.sanitizeWebsiteContent(content),
        updatedAt: serverTimestamp(),
      };
      if (snap.exists()) {
        await updateDoc(ref, payload);
      } else {
        await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  private sanitizePaymentGateways(s: PaymentGatewaySettings) {
    return {
      bkashNumber: clampStr(s.bkashNumber, 60),
      bkashType: clampStr(s.bkashType, 80),
      nagadNumber: clampStr(s.nagadNumber, 60),
      nagadType: clampStr(s.nagadType, 80),
      rocketNumber: clampStr(s.rocketNumber, 60),
      rocketType: clampStr(s.rocketType, 80),
      binancePayId: clampStr(s.binancePayId, 80),
      binanceTrc20Address: clampStr(s.binanceTrc20Address, 120),
      binanceBep20Address: clampStr(s.binanceBep20Address, 120),
      instructionsNote: clampStr(s.instructionsNote, 600),
    };
  }

  public async syncPaymentGateways(settings: PaymentGatewaySettings) {
    if (!auth.currentUser) return;
    const path = 'siteConfig/paymentGateways';
    try {
      const ref = doc(firestoreDb, 'siteConfig', 'paymentGateways');
      const snap = await getDoc(ref);
      const payload = {
        ...this.sanitizePaymentGateways(settings),
        updatedAt: serverTimestamp(),
      };
      if (snap.exists()) {
        await updateDoc(ref, payload);
      } else {
        await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  public async syncPaymentRequestCreate(req: PaymentRequest) {
    if (!auth.currentUser) return;
    const id = sanitizeDocId(req.id);
    const uid = auth.currentUser.uid;
    try {
      const payload: Record<string, unknown> = {
        id,
        userId: uid,
        userName: clampStr(req.userName, 120) || 'User',
        userEmail: clampStr(req.userEmail, 160),
        packageId: clampStr(req.packageId, 60),
        packageName: clampStr(req.packageName, 80),
        packageCredits: Math.max(0, Math.min(10000000, Math.floor(Number(req.packageCredits || 0)))),
        method: req.method,
        currency: req.currency,
        amount: Math.max(0.01, Math.min(1000000, Number(req.amount))),
        senderAccount: clampStr(req.senderAccount, 120),
        transactionId: clampStr(req.transactionId, 120),
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      if (req.note) {
        payload.note = clampStr(req.note, 500);
      }
      await setDoc(doc(firestoreDb, 'paymentRequests', id), payload);

      // Update user's planStatus to pending if not active
      const userRef = doc(firestoreDb, 'users', uid);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists() && (!userSnap.data().planStatus || userSnap.data().planStatus === 'none')) {
        await updateDoc(userRef, {
          planStatus: 'pending',
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `paymentRequests/${id}`);
    }
  }

  public async syncPaymentRequestReview(
    req: PaymentRequest,
    userPlanPatch?: { plan?: string; planStatus: 'none' | 'pending' | 'active'; credits?: number }
  ) {
    if (!auth.currentUser) return;
    const id = sanitizeDocId(req.id);
    try {
      await updateDoc(doc(firestoreDb, 'paymentRequests', id), {
        status: req.status,
        adminNote: clampStr(req.adminNote || '', 500),
        reviewedBy: clampStr(req.reviewedBy || auth.currentUser.email || '', 160),
        reviewedAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      if (userPlanPatch && req.userId) {
        const userRef = doc(firestoreDb, 'users', sanitizeDocId(req.userId));
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          const patch: Record<string, unknown> = {
            planStatus: userPlanPatch.planStatus,
            updatedAt: serverTimestamp(),
          };
          if (userPlanPatch.plan !== undefined) {
            patch.plan = clampStr(userPlanPatch.plan, 80);
            patch.planUpdatedAt = serverTimestamp();
          }
          if (userPlanPatch.credits !== undefined) {
            patch.credits = Math.max(0, Math.min(10000000, Math.floor(Number(userPlanPatch.credits) || 0)));
          }
          await updateDoc(userRef, patch);
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `paymentRequests/${id}`);
    }
  }
}

export const firestoreSync = new FirestoreSyncService();
