/**
 * Firestore Security Rules Test Suite (Dirty Dozen Verification)
 * Run against Firebase Emulator Suite (@firebase/rules-unit-testing)
 * verifying every adversarial payload returns PERMISSION_DENIED.
 */

export interface DirtyDozenCase {
  id: number;
  name: string;
  collectionPath: string;
  operation: 'create' | 'update' | 'get' | 'list' | 'delete';
  expected: 'PERMISSION_DENIED';
  payload?: Record<string, unknown>;
}

export const DIRTY_DOZEN_CASES: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Self-Role Escalation on User Create',
    collectionPath: 'users/user_attacker',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: {
      id: 'user_attacker',
      fullName: 'Attacker',
      mobile: '+15550000000',
      gmail: 'attacker@gmail.com',
      role: 'admin',
      status: 'active',
      planStatus: 'none',
    },
  },
  {
    id: 2,
    name: 'Profile Role/Plan Shadow Update',
    collectionPath: 'users/user_attacker',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: {
      fullName: 'Attacker Updated',
      planStatus: 'active',
      plan: 'Agency Lifetime',
    },
  },
  {
    id: 3,
    name: 'Ghost Field Injection on SavedResult',
    collectionPath: 'savedResults/res_ghost_01',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: {
      id: 'res_ghost_01',
      userId: 'user_a',
      toolSlug: 'user-agent-generator',
      toolName: 'User Agent Generator',
      title: 'Test',
      resultsText: 'UA',
      count: 1,
      savedDate: 'Nov 13, 2026',
      isVerified: true,
    },
  },
  {
    id: 4,
    name: 'Unverified Email Spoofing Admin Write',
    collectionPath: 'tools/tool_ua',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: { enabled: false },
  },
  {
    id: 5,
    name: 'Cross-User PII Get',
    collectionPath: 'users/user_victim',
    operation: 'get',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Unscoped Collection List on SavedResults',
    collectionPath: 'savedResults',
    operation: 'list',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'ID Poisoning with Oversized / Invalid ID',
    collectionPath: `usageHistory/${'x'.repeat(200)}`,
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'UA Pool Terminal State Reset / Double-Spend',
    collectionPath: 'uaPool/ua_used_01',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: {
      used: false,
      usedBy: 'user_attacker',
    },
  },
  {
    id: 9,
    name: 'Payment Self-Approval by Non-Admin',
    collectionPath: 'paymentRequests/pay_01',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: {
      id: 'pay_01',
      userId: 'user_attacker',
      userName: 'Attacker',
      userEmail: 'attacker@gmail.com',
      packageId: 'pkg_agency',
      packageName: 'Agency Lifetime',
      method: 'bKash',
      currency: 'BDT',
      amount: 2500,
      senderAccount: '01700000000',
      transactionId: 'FAKE1234',
      status: 'approved',
    },
  },
  {
    id: 10,
    name: 'Client-Forged Timestamp Instead of request.time',
    collectionPath: 'supportTickets/ticket_forged',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: {
      id: 'ticket_forged',
      userId: 'user_a',
      userName: 'User A',
      userEmail: 'usera@gmail.com',
      subject: 'Forged time',
      status: 'open',
      createdAt: '2020-01-01T00:00:00.000Z',
      updatedAt: '2020-01-01T00:00:00.000Z',
    },
  },
  {
    id: 11,
    name: 'Orphaned Support Message Creation',
    collectionPath: 'supportTickets/missing_ticket_999/messages/msg_01',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: {
      id: 'msg_01',
      ticketId: 'missing_ticket_999',
      ticketOwnerId: 'user_a',
      sender: 'user',
      senderUid: 'user_a',
      senderName: 'User A',
      text: 'Hello',
      timestamp: '12:00 PM',
    },
  },
  {
    id: 12,
    name: 'Value Poisoning with Invalid Amount Type & Oversized Note',
    collectionPath: 'paymentRequests/pay_poison',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: {
      id: 'pay_poison',
      userId: 'user_a',
      userName: 'User A',
      userEmail: 'usera@gmail.com',
      packageId: 'pkg_starter',
      packageName: 'Starter Pass',
      method: 'bKash',
      currency: 'BDT',
      amount: '0',
      senderAccount: '01700000000',
      transactionId: 'TRX12345',
      note: 'A'.repeat(1000),
      status: 'pending',
    },
  },
];

// Verification guard ensuring all 12 Dirty Dozen assertions exist
export function verifyDirtyDozenCoverage(): boolean {
  return DIRTY_DOZEN_CASES.length === 12 && DIRTY_DOZEN_CASES.every(c => c.expected === 'PERMISSION_DENIED');
}
